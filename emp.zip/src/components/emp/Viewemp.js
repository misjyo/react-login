import React, { useState, useEffect } from "react";
import Table from "react-bootstrap/Table";
import { Link } from "react-router-dom";
const newArr = []
function Viewemp() {
  const token = localStorage.getItem("data");
  console.log(token);
  const data = newArr.push(token)
  console.log("data", data);
  console.log("array",newArr)
  

  return (
    <>
      <Link
        to="/addemp"
        style={{ textDecoration: "none", fontSize: "20px", color: "black" }}
      >
        Add Employee
      </Link>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Technical Skills</th>
            <th>Experience</th>
            <th>Communication</th>
            <th>Technical Rating</th>
            <th>Company</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>John</td>
            <td>Html</td>
            <td>2 years</td>
            <td>English</td>
            <td>5 star</td>
            <td>control f5</td>
          </tr>
        </tbody>
      </Table>
    </>
  );
}

export default Viewemp;
